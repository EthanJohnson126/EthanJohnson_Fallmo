﻿using UnityEngine;
using System.Collections;

public class ScoreandTimer : MonoBehaviour {

	//The actual timer.
	public float timefromBegin;

	//Upon the player losing, they reset the current level.
	public delegate void EndLevel ();
	EndLevel levelEnd;

	//Upon this being
	public bool switchEnd = false;
	
	void Start () {
		//Adding the actions to the delgate.
		levelEnd += OnLoseEnd;
		levelEnd += ResetLevel;
	}

	void Update () {
		//Increment timer as time passes.
		timefromBegin += Time.deltaTime;

		//The fall script calls the switchEnd bool, changes it to true, so the level can reset.
		if(switchEnd == true){
			levelEnd();
		}
	}

	//Reset the level.
	void ResetLevel(){
		Application.LoadLevel(Application.loadedLevel);
	}

	//Print the time spent in the level.
	void OnLoseEnd(){
		print (timefromBegin);
	}
}
