﻿using UnityEngine;
using System.Collections;

public class NextLevelScript : MonoBehaviour {

	//The amount of pieces in each individual puzzle.
    public int amountinPuzzle;
	
	//Calls the next level after the current one.
    public int nextLevel;

	void Update () {

		//When all pieces are destroyed, load the next level.
        if (amountinPuzzle <= 0)
        {
            Application.LoadLevel(nextLevel);
        }
	
	}
}
