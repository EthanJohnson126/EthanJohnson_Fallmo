﻿using UnityEngine;
using System.Collections;

public class DestroyonClick : MonoBehaviour {

	public TurnonPhysics toP;

	public bool waitBool = true;

    public NextLevelScript nlS;

	void OnMouseDown(){

		//When the object is clicked, destroy it.
		Destroy(this.gameObject);
		//Turn on the physics loop.
		toP.StartPhysics();


        //Tells the script which switches levels how many blocks are left in the puzzle.
        nlS.amountinPuzzle--;
		
	}
}
