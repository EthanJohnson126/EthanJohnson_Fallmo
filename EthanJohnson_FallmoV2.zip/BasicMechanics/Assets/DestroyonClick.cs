﻿using UnityEngine;
using System.Collections;

public class DestroyonClick : MonoBehaviour {

	public TurnonPhysics toP;

	void OnMouseDown(){
		//When the object is clicked, destroy it.
		Destroy(this.gameObject);
		//Turn on the physics loop.
		toP.StartPhysics();
	}
}
