﻿using UnityEngine;
using System.Collections;

public class NextLevelScript : MonoBehaviour {

    public int amountinPuzzle;

    public int nextLevel;

	void Update () {

        if (amountinPuzzle <= 0)
        {
            Application.LoadLevel(nextLevel);
        }
	
	}
}
