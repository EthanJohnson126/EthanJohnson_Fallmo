using UnityEngine;
using UnityEditor;
using System.Collections;
using StrumpyShaderEditor;

public class StrumpyPreviewWindow : PreviewWindowInternal {
}
