﻿using UnityEngine;
using System.Collections;

public class DestroyonClick : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnMouseDown(){
		//When the object is clicked, destroy it.
		Destroy(this.gameObject);
	}
}
