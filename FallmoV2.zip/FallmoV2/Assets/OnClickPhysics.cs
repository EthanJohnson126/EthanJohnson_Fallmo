﻿using UnityEngine;
using System.Collections;

public class OnClickPhysics : MonoBehaviour {

	public Rigidbody[] allblockPhysics;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetMouseButtonDown (0)) {
		
			foreach(Rigidbody r in allblockPhysics)
			{
				r.isKinematic = false;
				r.useGravity = true;
			}

			Invoke("ResetPhysics", 1);

		}
	
	}

	void ResetPhysics(){

		foreach(Rigidbody r in allblockPhysics)
		{
			r.isKinematic = true;
			r.useGravity = false;
		}

	}
}
